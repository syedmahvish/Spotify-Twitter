import PostInsert from './PostInsert'
import Home from './Home'

export { PostInsert, Home }
