const postData = require("./postData");
const commentData = require("./commentsData");
const likeData = require("./likesData");
const userData = require("./userData");
module.exports = { post: postData, comment : commentData, likes : likeData, users: userData};
